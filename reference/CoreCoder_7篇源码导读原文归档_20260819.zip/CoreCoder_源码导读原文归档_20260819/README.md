# CoreCoder 源码导读原文归档

本目录保存公开仓库 `he-yufeng/CoreCoder` 中 `article/` 目录的中文索引及 7 篇 Claude Code 源码导读的原始 Markdown 下载副本。正文保持来自 GitHub Raw 的原始内容，不对文章文字、代码示例或链接作任何改写。

归档仅用于离线阅读和资料留存。`SOURCE_METADATA.tsv` 记录文章的 Git blob SHA、原始 Raw URL 与网页 URL；`CHECKSUMS.sha256` 记录下载副本的 SHA-256 校验值。请以原始链接和元数据文件判断文章的当前版本与来源。
